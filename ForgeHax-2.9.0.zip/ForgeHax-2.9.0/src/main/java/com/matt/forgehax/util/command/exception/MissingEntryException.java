package com.matt.forgehax.util.command.exception;

/**
 * Created on 6/8/2017 by fr1kin
 */
public class MissingEntryException extends CommandExecuteException {

    public MissingEntryException(String message) {
        super(message);
    }
}

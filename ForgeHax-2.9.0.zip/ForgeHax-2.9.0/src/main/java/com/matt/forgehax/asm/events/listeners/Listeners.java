package com.matt.forgehax.asm.events.listeners;

/**
 * Created on 5/12/2017 by fr1kin
 */
public interface Listeners {

    ListenerObject<BlockModelRenderListener> BLOCK_MODEL_RENDER_LISTENER = new ListenerObject<>();
}

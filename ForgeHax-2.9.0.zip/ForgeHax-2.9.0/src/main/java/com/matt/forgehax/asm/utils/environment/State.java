package com.matt.forgehax.asm.utils.environment;

/**
 * Created on 5/26/2017 by fr1kin
 */
public enum State {
    NORMAL,
    SRG,
    OBFUSCATED
}

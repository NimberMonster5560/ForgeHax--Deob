package com.matt.forgehax.asm.utils.transforming;

/**
 * Created on 2/13/2018 by fr1kin
 */
public @interface RegisterClassPatch {

}

package com.matt.forgehax.util.command.flags;

/**
 * Created on 6/8/2017 by fr1kin
 */
public interface ICommandFlag {

}

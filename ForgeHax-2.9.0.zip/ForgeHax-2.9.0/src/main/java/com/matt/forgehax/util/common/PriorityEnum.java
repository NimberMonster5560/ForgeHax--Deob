package com.matt.forgehax.util.common;

/**
 * Created on 6/8/2017 by fr1kin
 */
public enum PriorityEnum {
    HIGHEST,
    HIGH,
    DEFAULT,
    LOW,
    LOWEST,
    ;
}

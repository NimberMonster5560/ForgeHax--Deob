package com.github.lunatrius.schematica.proxy;

public abstract class CommonProxy {
}

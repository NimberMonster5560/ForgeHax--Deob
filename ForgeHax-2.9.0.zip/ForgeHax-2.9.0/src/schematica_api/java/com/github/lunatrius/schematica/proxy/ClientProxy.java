package com.github.lunatrius.schematica.proxy;

import com.github.lunatrius.schematica.client.world.SchematicWorld;

public class ClientProxy extends CommonProxy {

    public static SchematicWorld schematic;
}
